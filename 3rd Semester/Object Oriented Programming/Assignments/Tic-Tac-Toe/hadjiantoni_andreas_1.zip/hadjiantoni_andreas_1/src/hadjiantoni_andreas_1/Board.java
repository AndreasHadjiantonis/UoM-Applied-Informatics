package hadjiantoni_andreas_1;

public class Board {

	private char[][] board = new char[3][3];
	private String line;
	private char[] columnsHeadings = new char[] {'A','B','C'};
	
	public Board() {
		 for (int i = 0; i<3; i++) 
			    for (int j = 0; j<3; j++) 
			    	board[i][j] = ' ';
	}
	
	public void printWelcome () {
		
		System.out.println("************");
		System.out.println("Tic-Tac-Toe!");
		System.out.println("************");
		
		System.out.println("Please enter the column (A, B or C) and then the row (1, 2, or 3) of your move.");
		System.out.println("");
	}

	public void printBoard() {
		 
		System.out.println("  A B C");
		
		System.out.println("1|" + board[0][0] + "|" + board[0][1] + "|" + board[0][2] + "|");
	        
		System.out.println("2|" + board[1][0] + "|" + board[1][1] + "|" + board[1][2]  + "|");
	        
		System.out.println("3|" + board[2][0] + "|" + board[2][1] + "|" + board[2][2] + "|");
	 }
	
	public boolean isGameWon(){
		
		for (int i = 0; i < 8; i++) {
			line = null;
 
            switch (i) {
            case 0:
            	line = "" + board[1][0] + board[1][1] + board[1][2];
                break;
            case 1:
            	line = "" + board[0][0] + board[0][1] + board[0][2];
                break;
            case 2:
                line = "" + board[2][0] + board[2][1] + board[2][2];
                break;
            case 3:
                line = "" + board[0][0] + board[1][1] + board[2][2];
                break;
            case 4:
                line = "" + board[0][2] + board[1][1] + board[2][0];
                break;
            case 5:
                line = "" + board[0][0] + board[1][0] + board[2][0];
                break;
            case 6:
                line = "" + board[0][1] + board[1][1] + board[2][1];
                break;
            case 7:
                line = "" + board[0][2] + board[1][2] + board[2][2];
                break;
            }
            
            if (line.equals("XXX")) {
            	System.out.println("You win!");
            	return true;
            }
            else if (line.equals("OOO")) {
            	System.out.println("Computer Wins!");
            	return true;
            }
        }
		
		return false;
	}
	
	public boolean playerPlaying(String s) {
		
		if(s.equals("A1")) 
			if(board[0][0] == ' '){
				board[0][0] = 'X';
				return true;
			}
			else {
				System.out.println("The space entered is already taken.");
				System.out.print("Player Move (X):");
				return false;
			}
		if(s.equals("A2")) 
			if(board[1][0] == ' '){
				board[1][0] = 'X';
				return true;
			}
			else {
				System.out.println("The space entered is already taken.");
				System.out.print("Player Move (X):");
				return false;
			}
		if(s.equals("A3")) 
			if(board[2][0] == ' '){
				board[2][0] = 'X';
				return true;
			}
			else {
				System.out.println("The space entered is already taken.");
				System.out.print("Player Move (X):");
				return false;
			}
		if(s.equals("B1")) 
			if(board[0][1] == ' '){
				board[0][1] = 'X';
				return true;
			}
			else {
				System.out.println("The space entered is already taken.");
				System.out.print("Player Move (X):");
				return false;
			}
		if(s.equals("B2")) 
			if(board[1][1] == ' '){
				board[1][1] = 'X';
				return true;
			}
			else {
				System.out.println("The space entered is already taken.");
				System.out.print("Player Move (X):");
				return false;
			}
		if(s.equals("B3")) 
			if(board[2][1] == ' '){
				board[2][1] = 'X';
				return true;
			}
			else {
				System.out.println("The space entered is already taken.");
				System.out.print("Player Move (X):");
				return false;
			}
		if(s.equals("C1")) 
			if(board[0][2] == ' '){
				board[0][2] = 'X';
				return true;
			}
			else {
				System.out.println("The space entered is already taken.");
				System.out.print("Player Move (X):");
				return false;
			}
		if(s.equals("C2")) 
			if(board[1][2] == ' '){
				board[1][2] = 'X';
				return true;
			}
			else {
				System.out.println("The space entered is already taken.");
				System.out.print("Player Move (X):");
				return false;
			}
		if(s.equals("C3")) 
			if(board[2][2] == ' '){
				board[2][2] = 'X';
				return true;
			}
			else {
				System.out.println("The space entered is already taken.");
				System.out.print("Player Move (X):");
				return false;
			}
		
		System.out.println("Invalid Input: Please enter the column and row of your move (Example: A1)");
		System.out.print("Player Move (X):");
		return false;
	}

	public boolean computerPlaying(int r, int c) {
		
		if(board[r][c] == ' ') {
			board[r][c] = 'O';
			return true;
		}
		else {
			return false;
		}
	}
	
	public void printComputersMove(int r, int c) {
		
		System.out.print(columnsHeadings[c]);
		System.out.println(r+1);
	}
}