//ics21138 andreas hadjiantoni
package hadjiantoni_andreas_1;

import java.util.Scanner;
import java.util.Random;

public class Main {

	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		Random randomNumber = new Random();
		Board board = new Board();
		
		int row,column;
		String position;
		
		board.printWelcome();
		
		board.printBoard();
		
		for(int i = 0; i<9; i++) {
			
			if(board.isGameWon())
				break;
			
			if(i%2 == 0) {    //if mod 2 για εναλλαγή παικτών μέσω της for. Μία ο ένας, μία ο άλλος.
				System.out.print("Player Move (X):");
				while(true) {
			
					position = in.nextLine();   
					if(board.playerPlaying(position)) 
						break;
				}
				board.printBoard();
			}
			else {
				System.out.print("Computer Move(O):");
				while(true) {
					
					row = randomNumber.nextInt(3);
					column = randomNumber.nextInt(3);
					if(board.computerPlaying(row, column)) {
						
						board.printComputersMove(row, column);
						board.printBoard();
						break;
					}	
				}		
			}
			
			if(i == 8){// Αν το i γίνει 8 τότε όλες οι θέσεις του πίνακα θα γεμίσουν
				
				if(board.isGameWon()) { //Έλεγχος για τελευταία φορά, θεωρώ πως σε ένα κανονικό παιχίδι
										//δεν θα γίνει κάτι τέτοιο αλλά με τυχαίες τιμές υπάρχει πιθανότητα
				}
				else
					System.out.println("-----Draw-----");
			}
		}
		in.close();
	}
}	